class CustomError {
  final String message;

  CustomError({ required this.message});
}
