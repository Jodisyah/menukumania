import '/TANGSEL/func_jadwaltangsel.dart';
import '/TANGSEL/jadwal%20customer/kamis/search_jadwal_kamis.dart';
import '/theme.dart';
import '/Depok/func_jadwalDepok.dart';
// import 'package:e_commerce/widgets/fetchproducts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';

class HariKamisTangsel extends StatefulWidget {
  @override
  _HariKamisTangselState createState() => _HariKamisTangselState();
}
class _HariKamisTangselState extends State<HariKamisTangsel> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         actions: [Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
              onPressed: () 
                  => Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => searchJadwalKamisTangsel()),
                  ),
              icon: const Icon(Icons.search_sharp),
            ),
        ),],
        title: Text(
          'Kamis',
          style: GoogleFonts.poppins(
            fontSize: 23,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: kPrimaryColor,
      ),
      body: SafeArea(
        child: JadwalCateringTangsel("add_customers_tangsel_kamis"),
      ),
    );
  }
}
