import 'package:MenukuMania/TANGSEL/bottom_nav_pages/jadwal.dart';
import 'package:MenukuMania/TANGSEL/jadwal%20customer/jumat/screen_jadwal.dart';
import 'package:MenukuMania/TANGSEL/jadwal%20customer/selasa/screen_jadwal.dart';

import '/TANGSEL/func_jadwaltangsel.dart';
import '/TANGSEL/jadwal%20customer/jumat/search_jadwal_jumat.dart';
import '/theme.dart';
import '/Depok/func_jadwalDepok.dart';
// import 'package:e_commerce/widgets/fetchproducts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';

class HariJumatTangsel extends StatefulWidget {
  @override
  _HariJumatTangselState createState() => _HariJumatTangselState();
}

class _HariJumatTangselState extends State<HariJumatTangsel> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         actions: [Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
              onPressed: () 
                  => Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => searchJadwalJumatTangsel()),
                  ),
              icon: const Icon(Icons.search_sharp),
            ),
        ),],
        title: Text(
          'Jumat',
          style: GoogleFonts.poppins(
            fontSize: 23,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: kPrimaryColor,
      ),
      body: SafeArea(
        child: JadwalCateringTangsel('add_customers_tangsel_jumat'),
      ),
    );
  }
}
