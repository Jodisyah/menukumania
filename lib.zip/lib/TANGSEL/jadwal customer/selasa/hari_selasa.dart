import '/TANGSEL/func_jadwaltangsel.dart';
import '/TANGSEL/jadwal%20customer/selasa/search_jadwal_selasa.dart';
import '/theme.dart';
import '/Depok/func_jadwalDepok.dart';
// import 'package:e_commerce/widgets/fetchproducts.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
// import 'package:flutter/src/foundation/key.dart';
// import 'package:flutter/src/widgets/container.dart';
// import 'package:flutter/src/widgets/framework.dart';

class HariSelasaTangsel extends StatefulWidget {
  @override
  _HariSelasaTangselState createState() => _HariSelasaTangselState();
}

class _HariSelasaTangselState extends State<HariSelasaTangsel> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         actions: [Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
              onPressed: () 
                  => Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => searchJadwalSelasaTangsel()),
                  ),
              icon: const Icon(Icons.search_sharp),
            ),
        ),],
        title: Text(
          'Selasa',
          style: GoogleFonts.poppins(
            fontSize: 23,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: kPrimaryColor,
      ),
      body: SafeArea(
        child: JadwalCateringTangsel("add_customers_tangsel_selasa"),
      ),
    );
  }
}
