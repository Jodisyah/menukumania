import '/Depok/jadwal%20customer/jumat/search_jadwal_jumat.dart';
import '/theme.dart';
import '/Depok/func_jadwalDepok.dart';
// import 'package:e_commerce/widgets/fetchproducts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';

class HariJumat extends StatefulWidget {
  @override
  _HariJumatState createState() => _HariJumatState();
}

class _HariJumatState extends State<HariJumat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
              onPressed: () 
                  => Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => searchJadwalJumat()),
                  ),
              icon: const Icon(Icons.search_sharp),
            ),
        ),],
        title: Text(
          'Jumat',
          style: GoogleFonts.poppins(
            fontSize: 23,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: kPrimaryColor,
      ),
      body: SafeArea(
        child: Jadwal("add_customers_jumat"),
      ),
    );
  }
}
