import 'package:cloud_firestore/cloud_firestore.dart';
import '/Depok/jadwal%20customer/senin/search_jadwal_senin.dart';
import '/theme.dart';
import '/Depok/func_jadwalDepok.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:e_commerce/widgets/fetchproducts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';

class HariSenin extends StatefulWidget {
  @override
  _HariSeninState createState() => _HariSeninState();
}

class _HariSeninState extends State<HariSenin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
              onPressed: () 
                  => Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) => searchJadwalSenin()),
                  ),
              icon: const Icon(Icons.search_sharp),
            ),
        ),],
          title: Text(
            'Senin',
            style: GoogleFonts.poppins(
              fontSize: 23,
              fontWeight: FontWeight.w500,
            ),
          ),
          backgroundColor: kPrimaryColor,
          ),
      body: SafeArea(
        child: Jadwal("add_customers_senin"),
      ),
    );
  }
}
